# SADEE Optimizer v2.1

Android optimizer + separate ADMIN dashboard.

## Included
- Main SADEE Optimizer APK
- Separate ADMIN Key Dashboard APK
- 3-day free key: `paid01`
- 7-day / 1-month / lifetime license generation
- Buy-plan SMS composer to `0760625028`
- In-app encrypted admin messages
- Gaming-style ADMIN branding

## GitHub message setup
The ADMIN app writes encrypted message JSON files into this repository using the GitHub Contents API.

Create a GitHub fine-grained personal access token with **Contents: Read and Write** permission for this repository. Enter it only in the ADMIN app when sending a message; it is not embedded in the APK.

The user app reads the public encrypted message file and decrypts it locally with the recipient license key. The repository therefore stores ciphertext rather than plaintext message content.

Repository:
`i73818026-jpg/Sadee-Optimizer-`

## Build
The included GitHub Actions workflow uses:
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android SDK 35

It builds both debug APKs and uploads them as Actions artifacts.
