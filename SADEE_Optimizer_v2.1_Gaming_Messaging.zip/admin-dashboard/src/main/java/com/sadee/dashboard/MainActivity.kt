package com.sadee.dashboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.*
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import org.json.JSONObject

class MainActivity : Activity() {
    private val green = Color.rgb(0,245,160)
    private val blue = Color.rgb(91,184,255)
    private val purple = Color.rgb(170,105,255)
    private val orange = Color.rgb(255,180,84)
    private val bg = Color.rgb(5,7,10)
    private val panel = Color.rgb(13,18,24)
    private val repoOwner = "i73818026-jpg"
    private val repoName = "Sadee-Optimizer-"
    private val branch = "main"
    private val secret = "SADEE_OPTIMIZER_LOCAL_SECRET_2026"

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); show() }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun tv(t:String,s:Float,c:Int,b:Boolean=false)=TextView(this).apply {
        text=t;textSize=s;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD
        setPadding(dp(4),dp(4),dp(4),dp(4))
    }
    private fun box():LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14))
        setBackgroundColor(panel);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(10),dp(10),dp(10),0)}
    }
    private fun button(t:String,c:Int,fn:()->Unit)=Button(this).apply{
        text=t;setTextColor(Color.BLACK);setBackgroundColor(c);isAllCaps=false
        setTypeface(null,Typeface.BOLD);setOnClickListener{fn()}
        layoutParams=LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(10)}
    }

    private fun sign(payload:String):String=MessageDigest.getInstance("SHA-256")
        .digest((secret+"|"+payload).toByteArray()).joinToString(""){"%02x".format(it)}.take(10).uppercase(Locale.US)

    private fun make(days:Long):String {
        val expiry=if(days==0L) Long.MAX_VALUE else System.currentTimeMillis()+days*86400000L
        val payload="SADEE|$expiry"
        return "SAD-$expiry-${sign(payload)}"
    }

    private fun copy(k:String){
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SADEE key",k))
        Toast.makeText(this,"Key copied",Toast.LENGTH_SHORT).show()
    }

    private fun messageFilePath(key:String):String {
        val hash=MessageDigest.getInstance("SHA-256")
            .digest(key.trim().uppercase(Locale.US).toByteArray())
            .joinToString(""){"%02x".format(it)}
        return "messages/$hash.json"
    }

    private fun keyBytes(key:String):ByteArray =
        MessageDigest.getInstance("SHA-256")
            .digest(key.trim().uppercase(Locale.US).toByteArray()).copyOf(16)

    private fun encrypt(key:String, message:String):Pair<String,String> {
        val iv=ByteArray(12)
        java.security.SecureRandom().nextBytes(iv)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE,SecretKeySpec(keyBytes(key),"AES"),GCMParameterSpec(128,iv))
        val data=cipher.doFinal(message.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(iv,Base64.NO_WRAP) to Base64.encodeToString(data,Base64.NO_WRAP)
    }

    private fun githubRequest(token:String, method:String, path:String, body:String?=null):Pair<Int,String> {
        val url=URL("https://api.github.com/repos/$repoOwner/$repoName/contents/$path")
        val con=url.openConnection() as HttpURLConnection
        con.connectTimeout=10000;con.readTimeout=10000;con.requestMethod=method
        con.setRequestProperty("Accept","application/vnd.github+json")
        con.setRequestProperty("Authorization","Bearer $token")
        con.setRequestProperty("X-GitHub-Api-Version","2022-11-28")
        if(body!=null){
            con.doOutput=true
            con.setRequestProperty("Content-Type","application/json; charset=utf-8")
            con.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))}
        }
        val code=con.responseCode
        val stream=if(code in 200..299) con.inputStream else con.errorStream
        val text=stream?.bufferedReader()?.use{it.readText()} ?: ""
        con.disconnect()
        return code to text
    }

    private fun sendMessage(token:String, recipientKey:String, message:String, status:TextView) {
        Thread {
            try {
                val path=messageFilePath(recipientKey)
                val (iv,data)=encrypt(recipientKey,message)
                val content=JSONObject().apply{
                    put("version",1)
                    put("timestamp",System.currentTimeMillis())
                    put("iv",iv)
                    put("data",data)
                }.toString()
                val encoded=Base64.encodeToString(content.toByteArray(Charsets.UTF_8),Base64.NO_WRAP)

                var sha:String?=null
                val get=githubRequest(token,"GET",path)
                if(get.first==200) sha=JSONObject(get.second).optString("sha",null)

                val payload=JSONObject().apply{
                    put("message","Admin message for $recipientKey")
                    put("content",encoded)
                    put("branch",branch)
                    if(sha!=null) put("sha",sha)
                }.toString()

                val put=githubRequest(token,"PUT",path,payload)
                runOnUiThread {
                    if(put.first in 200..299) {
                        status.text="✓ Message sent successfully"
                        status.setTextColor(green)
                    } else {
                        status.text="✕ GitHub error ${put.first}: check token/repository permissions"
                        status.setTextColor(Color.rgb(255,92,92))
                    }
                }
            } catch(e:Exception) {
                runOnUiThread {
                    status.text="✕ Send failed: ${e.message ?: "network error"}"
                    status.setTextColor(Color.rgb(255,92,92))
                }
            }
        }.start()
    }

    private fun show(){
        val scroll=ScrollView(this)
        val col=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(0,dp(10),0,dp(30))
        }
        val logo=ImageView(this).apply{setImageResource(com.sadee.dashboard.R.drawable.admin_logo);scaleType=ImageView.ScaleType.CENTER_INSIDE}
        col.addView(logo,LinearLayout.LayoutParams(-1,dp(120)))
        col.addView(tv("⚡ ADMIN",30f,Color.WHITE,true).apply{setPadding(dp(18),0,dp(18),0)})
        col.addView(tv("SADEE CONTROL CENTER • GAMING EDITION",12f,green,true).apply{setPadding(dp(18),0,dp(18),0)})

        val send=box()
        send.addView(tv("💬 SEND PRIVATE MESSAGE",18f,purple,true))
        send.addView(tv("Message is encrypted with the recipient license key. Only that user app can decrypt it.",11f,Color.LTGRAY))

        val token=EditText(this).apply{
            hint="GitHub token (Contents: Read/Write)"
            setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);setSingleLine(true)
            inputType=0x00000081
        }
        send.addView(token,LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(10)})

        val key=EditText(this).apply{
            hint="Recipient license key"
            setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);setSingleLine(true)
        }
        send.addView(key,LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(10)})

        val message=EditText(this).apply{
            hint="Type message..."
            setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);gravity=Gravity.TOP
            minLines=5;setPadding(dp(12),dp(12),dp(12),dp(12))
        }
        send.addView(message,LinearLayout.LayoutParams(-1,dp(130)).apply{topMargin=dp(10)})

        val status=tv("Ready",12f,Color.LTGRAY)
        send.addView(status)
        send.addView(button("📤 SEND TO USER",purple){
            val t=token.text.toString().trim()
            val k=key.text.toString().trim()
            val m=message.text.toString().trim()
            when {
                t.isEmpty() -> status.text="Enter a GitHub token"
                k.isEmpty() -> status.text="Enter recipient license key"
                m.isEmpty() -> status.text="Enter a message"
                else -> { status.text="Sending…"; sendMessage(t,k,m,status) }
            }
        })
        col.addView(send)

        val plans=listOf("7 DAYS" to 7L,"1 MONTH" to 30L,"LIFETIME" to 0L)
        for((name,days) in plans){
            val b=box()
            b.addView(tv(name,18f,green,true))
            b.addView(tv(if(days==0L)"LKR 2,200 • Lifetime" else if(days==7L)"LKR 500 • 7 days" else "LKR 1,000 • 30 days",14f,Color.WHITE))
            val out=EditText(this).apply{
                setTextColor(Color.WHITE);setTextSize(12f);setSingleLine(true);hint="Generated key";setHintTextColor(Color.GRAY)
            }
            b.addView(out)
            b.addView(button("GENERATE KEY",if(days==0L)green else blue){out.setText(make(days))})
            b.addView(button("COPY KEY",orange){if(out.text.isNotBlank())copy(out.text.toString())})
            col.addView(b)
        }

        val note=box()
        note.addView(tv("⚠ GITHUB SETUP",16f,Color.WHITE,true))
        note.addView(tv("Create a GitHub fine-grained token with Contents: Read and Write for i73818026-jpg/Sadee-Optimizer-. Do not put the token into source code. It is used only when you press SEND.",12f,Color.LTGRAY))
        note.addView(tv("Messages are stored as encrypted JSON files in the public repository, so the message text is not readable without the recipient key.",12f,Color.LTGRAY))
        col.addView(note)

        scroll.addView(col)
        setContentView(scroll)
    }
}
