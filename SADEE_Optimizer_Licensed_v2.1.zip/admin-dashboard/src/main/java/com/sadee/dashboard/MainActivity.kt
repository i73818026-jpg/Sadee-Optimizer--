package com.sadee.dashboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val green = Color.rgb(0,245,160)
    private val blue = Color.rgb(91,184,255)
    private val bg = Color.rgb(5,7,10)
    private val panel = Color.rgb(13,18,24)
    private val secret = "SADEE_OPTIMIZER_LOCAL_SECRET_2026"

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); show() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun tv(t:String,s:Float,c:Int,b:Boolean=false)=TextView(this).apply{ text=t;textSize=s;setTextColor(c);if(b)typeface=Typeface.DEFAULT_BOLD;setPadding(dp(4),dp(4),dp(4),dp(4)) }
    private fun box():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(14),dp(16),dp(14));setBackgroundColor(panel);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(dp(10),dp(10),dp(10),0)}}
    private fun button(t:String,c:Int,fn:()->Unit)=Button(this).apply{text=t;setTextColor(Color.BLACK);setBackgroundColor(c);isAllCaps=false;setTypeface(null,Typeface.BOLD);setOnClickListener{fn()};layoutParams=LinearLayout.LayoutParams(-1,dp(52)).apply{topMargin=dp(10)}}
    private fun sign(payload:String):String=MessageDigest.getInstance("SHA-256").digest((secret+"|"+payload).toByteArray()).joinToString(""){ "%02x".format(it)}.take(10).uppercase(Locale.US)
    private fun make(days:Long):String { val expiry=if(days==0L) Long.MAX_VALUE else System.currentTimeMillis()+days*86400000L; val payload="SADEE|$expiry"; return "SAD-$expiry-${sign(payload)}" }
    private fun copy(k:String){(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SADEE key",k));Toast.makeText(this,"Key copied",Toast.LENGTH_SHORT).show()}
    private fun show(){
        val scroll=ScrollView(this); val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);setPadding(0,dp(10),0,dp(20))};scroll.addView(col)
        col.addView(tv("SADEE KEY DASHBOARD",25f,Color.WHITE,true).apply{setPadding(dp(18),dp(20),dp(18),0)})
        col.addView(tv("Offline key generator • for SADEE Optimizer sales",12f,green,true).apply{setPadding(dp(18),0,dp(18),0)})
        val plans=listOf("7 DAYS" to 7L,"1 MONTH" to 30L,"LIFETIME" to 0L)
        for((name,days) in plans){ val b=box();b.addView(tv(name,18f,green,true));b.addView(tv(if(days==0L)"LKR 2,200 • Lifetime" else if(days==7L)"LKR 500 • 7 days" else "LKR 1,000 • 30 days",14f,Color.WHITE));val out=EditText(this).apply{setTextColor(Color.WHITE);setTextSize(12f);setSingleLine(true);hint="Generated key";setHintTextColor(Color.GRAY)};b.addView(out);b.addView(button("GENERATE KEY",if(days==0L)green else blue){out.setText(make(days))});b.addView(button("COPY KEY",Color.rgb(255,180,84)){if(out.text.isNotBlank())copy(out.text.toString())});col.addView(b)}
        val note=box();note.addView(tv("IMPORTANT",16f,Color.WHITE,true));note.addView(tv("This is an offline prototype. Keys are signed locally and the secret is embedded in both APKs. For real paid sales, move license verification to a server so keys cannot be forged by reverse engineering.",12f,Color.LTGRAY));col.addView(note)
        setContentView(scroll)
    }
}
