package com.sadee.optimizer

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.security.MessageDigest
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var scoreText: TextView
    private lateinit var ramText: TextView
    private lateinit var storageText: TextView
    private lateinit var batteryText: TextView
    private lateinit var deviceText: TextView
    private lateinit var statusText: TextView
    private var currentPage = "dashboard"
    private var gamingScreenOn = false
    private var gamingImmersive = false
    private val prefs by lazy { getSharedPreferences("license", Context.MODE_PRIVATE) }
    private val licenseSecret = "SADEE_OPTIMIZER_LOCAL_SECRET_2026"

    private val bg = Color.rgb(5, 7, 10)
    private val panel = Color.rgb(13, 18, 24)
    private val panel2 = Color.rgb(17, 24, 32)
    private val green = Color.rgb(0, 245, 160)
    private val blue = Color.rgb(91, 184, 255)
    private val orange = Color.rgb(255, 180, 84)
    private val red = Color.rgb(255, 92, 92)
    private val white = Color.WHITE
    private val muted = Color.rgb(137, 149, 161)
    private val handler = Handler(Looper.getMainLooper())
    private val liveRefresh = object : Runnable {
        override fun run() {
            if (currentPage == "dashboard") refreshMetrics()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isLicenseValid()) showDashboard() else showLicenseGate()
        handler.post(liveRefresh)
    }

    override fun onResume() {
        super.onResume()
        handler.post(liveRefresh)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(2), dp(2), dp(2), dp(2))
    }

    private fun rootColumn() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
    }

    private fun roundedBackground(fill: Int, stroke: Int = Color.TRANSPARENT, strokeWidth: Int = 0, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius.toInt()).toFloat()
            setColor(fill)
            if (stroke != Color.TRANSPARENT && strokeWidth > 0) setStroke(dp(strokeWidth), stroke)
        }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = roundedBackground(panel, Color.rgb(30, 65, 54), 1, 18f)
        elevation = dp(3).toFloat()
        layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(8), dp(10), dp(8), 0)
        }
    }

    private fun header(title: String, subtitle: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(10))
        background = roundedBackground(Color.rgb(6, 12, 15), Color.rgb(0, 115, 76), 1, 20f)

        val logo = ImageView(this@MainActivity).apply {
            setImageResource(com.sadee.optimizer.R.drawable.sadee_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(12) })

        val textCol = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
        textCol.addView(tv(title, 21f, white, true))
        textCol.addView(tv(subtitle, 11f, green, true))
        addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun scrollPage(): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val col = rootColumn()
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        return Pair(scroll, col)
    }

    private fun setScreen(page: String, body: View) {
        currentPage = page
        val root = rootColumn()
        root.addView(header("SADEE OPTIMIZER", "● REAL ANDROID MONITOR"))
        val frame = FrameLayout(this)
        frame.addView(body, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav())
        setContentView(root)
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(7, 10, 14))
            setPadding(0, dp(4), 0, dp(4))
        }
        listOf("⌂\nHome" to "dashboard", "⚡\nTurbo" to "turbo", "🎮\nGaming" to "gaming", "🧹\nClean" to "cleaner", "☰\nMore" to "more", "🔥\nFree Fire" to "freefire").forEach { (label, page) ->
            nav.addView(Button(this).apply {
                text = label
                textSize = 11f
                setTextColor(if (page == currentPage) green else muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { navigate(page) }
                isAllCaps = false
            }, LinearLayout.LayoutParams(0, dp(62), 1f))
        }
        return nav
    }

    private fun navigate(page: String) {
        if (page != "gaming") setGamingImmersive(false)
        when (page) {
            "dashboard" -> showDashboard()
            "turbo" -> showTurbo()
            "gaming" -> showGaming()
            "cleaner" -> showCleaner()
            "more" -> showMore()
            "freefire" -> showFreeFire()
        }
    }

    private fun licensePayload(expiresAt: Long): String = "SADEE|$expiresAt"

    private fun signature(payload: String): String {
        val bytes = MessageDigest.getInstance("SHA-256")
            .digest((licenseSecret + "|" + payload).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }.take(10).uppercase(Locale.US)
    }

    private fun makeLicenseKey(expiresAt: Long): String = "SAD-$expiresAt-${signature(licensePayload(expiresAt))}"

    private fun validatePaidKey(raw: String): Long? {
        val parts = raw.trim().uppercase(Locale.US).split("-")
        if (parts.size != 3 || parts[0] != "SAD") return null
        val expiry = parts[1].toLongOrNull() ?: return null
        if (parts[2] != signature(licensePayload(expiry))) return null
        return expiry
    }

    private fun isLicenseValid(): Boolean {
        val key = prefs.getString("key", null) ?: return false
        val expiry = prefs.getLong("expires", 0L)
        if (key == "paid01") return System.currentTimeMillis() < expiry
        val validExpiry = validatePaidKey(key) ?: return false
        return System.currentTimeMillis() < validExpiry && validExpiry == expiry
    }

    private fun activateKey(key: String): Boolean {
        val normalized = key.trim()
        if (normalized.equals("paid01", true)) {
            val existing = prefs.getLong("expires", 0L)
            val expiry = if (prefs.getString("key", null)?.equals("paid01", true) == true && existing > 0L) {
                existing
            } else {
                System.currentTimeMillis() + 3L * 24L * 60L * 60L * 1000L
            }
            prefs.edit().putString("key", "paid01").putLong("expires", expiry).apply()
            return true
        }
        val expiry = validatePaidKey(normalized) ?: return false
        if (expiry <= System.currentTimeMillis()) return false
        prefs.edit().putString("key", normalized).putLong("expires", expiry).apply()
        return true
    }

    private fun licenseStatus(): String {
        val expiry = prefs.getLong("expires", 0L)
        if (expiry <= 0L) return "Not activated"
        val remaining = ((expiry - System.currentTimeMillis()) / (24L * 60L * 60L * 1000L)).coerceAtLeast(0L)
        return if (remaining == 0L) "Expires within 24 hours" else "$remaining day(s) remaining"
    }

    private fun showLicenseGate() {
        val root = rootColumn()
        val scroll = ScrollView(this)
        val col = rootColumn()
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))

        val hero = card().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            background = roundedBackground(Color.rgb(7, 18, 15), green, 1, 24f)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.sadee_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        hero.addView(logo, LinearLayout.LayoutParams(-1, dp(170)))
        hero.addView(tv("SADEE OPTIMIZER", 25f, white, true))
        hero.addView(tv("GAMING EDITION • LICENSE", 12f, green, true))
        col.addView(hero)

        val trial = card()
        trial.addView(tv("🎁  3 DAYS FREE", 18f, green, true))
        trial.addView(tv("Free trial key", 11f, muted))
        trial.addView(tv("paid01", 22f, white, true))
        trial.addView(tv("Activate once to start the 3-day trial. After expiry, a paid key is required.", 12f, muted))
        val keyInput = EditText(this).apply {
            hint = "Enter license key"
            setTextColor(white)
            setHintTextColor(muted)
            setSingleLine(true)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = roundedBackground(panel2, Color.rgb(0, 115, 76), 1, 14f)
        }
        trial.addView(keyInput, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })
        trial.addView(button("ACTIVATE KEY", green) {
            if (activateKey(keyInput.text.toString())) {
                statusToast("License activated • ${licenseStatus()}")
                showDashboard()
            } else {
                statusToast("Invalid or expired key")
            }
        })
        col.addView(trial)

        val prices = card()
        prices.addView(tv("💎  PREMIUM PLANS", 18f, white, true))
        prices.addView(priceBox("7 DAYS", "LKR 500", "7-day access"))
        prices.addView(priceBox("1 MONTH", "LKR 1,000", "30-day access"))
        prices.addView(priceBox("LIFETIME", "LKR 2,200", "Lifetime access"))
        prices.addView(button("BUY / GET LICENSE KEY", blue) {
            AlertDialog.Builder(this)
                .setTitle("Get a SADEE key")
                .setMessage("Choose a plan, then get the license key from the seller. Paste the key above to activate.")
                .setPositiveButton("OK", null)
                .show()
        })
        col.addView(prices)

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun priceBox(plan: String, price: String, detail: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(panel2, Color.rgb(35, 80, 70), 1, 16f)
            layoutParams = LinearLayout.LayoutParams(-1, dp(72)).apply { setMargins(0, dp(8), 0, 0) }
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(tv(plan, 15f, green, true))
        left.addView(tv(detail, 11f, muted))
        box.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(tv(price, 18f, white, true))
        return box
    }

    private fun showDashboard() {
        val (scroll, col) = scrollPage()

        val hero = card().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            background = roundedBackground(Color.rgb(7, 18, 15), Color.rgb(0, 245, 160), 1, 22f)
        }
        val heroLogo = ImageView(this).apply {
            setImageResource(R.drawable.sadee_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        hero.addView(heroLogo, LinearLayout.LayoutParams(-1, dp(180)))
        hero.addView(tv("GAMING CORE • ONLINE", 16f, green, true))
        hero.addView(tv("Real Android telemetry • Safe optimization controls", 11f, muted))
        col.addView(hero)

        col.addView(tv("LIVE DASHBOARD", 24f, white, true).apply { setPadding(dp(10), dp(18), dp(10), 0) })
        col.addView(tv("Monitor your phone before you launch a game", 12f, muted).apply { setPadding(dp(10), 0, dp(10), 0) })

        val scoreCard = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
        scoreText = tv(calculateScore().toString(), 48f, green, true)
        scoreCard.addView(tv("REAL PERFORMANCE HEALTH", 11f, muted, true))
        scoreCard.addView(scoreText)
        scoreCard.addView(tv("Health score from RAM, storage, battery and thermal state. It is not a benchmark.", 11f, muted))
        scoreCard.addView(button("⚡  REFRESH / OPTIMIZE SCAN", green) {
            refreshMetrics()
            statusText.text = "Scan complete • live metrics refreshed"
            statusToast("Real device metrics refreshed")
        })
        col.addView(scoreCard)

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        ramText = tv("—", 22f, green, true)
        storageText = tv("—", 22f, blue, true)
        batteryText = tv("—", 22f, orange, true)
        deviceText = tv(deviceName(), 16f, white, true)
        addStat(r1, "RAM", ramText, green)
        addStat(r1, "Storage", storageText, blue)
        addStat(r2, "Battery", batteryText, orange)
        addStat(r2, "Device", deviceText, white)
        grid.addView(r1)
        grid.addView(r2)
        col.addView(grid)

        val c = card()
        c.addView(tv("LIVE STATUS", 11f, muted, true))
        statusText = tv("Monitoring active", 14f, green, true)
        c.addView(statusText)
        c.addView(tv("RAM, storage, battery, network and thermal values come from Android APIs. No root or paid API is used.", 12f, muted))
        col.addView(c)
        setScreen("dashboard", scroll)
        refreshMetrics()
    }

    private fun addStat(row: LinearLayout, label: String, value: TextView, color: Int) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel2)
        }
        box.addView(tv(label.uppercase(Locale.getDefault()), 10f, muted, true))
        value.setTextColor(color)
        box.addView(value)
        row.addView(box, LinearLayout.LayoutParams(0, dp(105), 1f).apply {
            setMargins(dp(6), dp(6), dp(6), dp(6))
        })
    }

    private fun showTurbo() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Turbo", 27f, white, true))
        col.addView(tv("Real safe actions — no fake RAM boost or overclock", 13f, muted))

        val c = card()
        c.addView(tv("⚡  DEVICE OPTIMIZATION", 16f, green, true))
        c.addView(tv("Android does not allow a normal app to overclock the CPU/GPU or force-stop other apps. This page uses real system information and opens the correct system controls.", 12f, muted))
        c.addView(button("REFRESH DEVICE HEALTH", green) {
            statusToast("Health refreshed: score ${calculateScore()}/100")
            if (::scoreText.isInitialized) scoreText.text = calculateScore().toString()
        })
        c.addView(button("OPEN BATTERY SETTINGS", blue) { openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS) })
        c.addView(button("OPEN APP SETTINGS", orange) { openAppSettings() })
        col.addView(c)

        val report = card()
        report.addView(tv("CURRENT HEALTH", 11f, muted, true))
        listRow(report, "🧠", "RAM", ramSummary())
        listRow(report, "💾", "Storage", storageSummary())
        listRow(report, "🔋", "Battery", batterySummary())
        listRow(report, "🌡️", "Thermal", thermalSummary())
        listRow(report, "📶", "Network", networkSummary())
        col.addView(report)
        setScreen("turbo", scroll)
    }

    private fun showGaming() {
        val (scroll, col) = scrollPage()

        val hero = card().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            background = roundedBackground(Color.rgb(8, 13, 20), Color.rgb(91, 184, 255), 1, 22f)
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.sadee_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        hero.addView(logo, LinearLayout.LayoutParams(-1, dp(150)))
        hero.addView(tv("⚡ GAMING MODE", 22f, green, true))
        hero.addView(tv("READY FOR BATTLE", 11f, blue, true))
        col.addView(hero)

        col.addView(tv("GAMING CONTROL CENTER", 22f, white, true).apply { setPadding(dp(10), dp(16), dp(10), 0) })
        col.addView(tv("Safe controls for this app — no fake overclocking", 12f, muted).apply { setPadding(dp(10), 0, dp(10), 0) })

        val c = card()
        c.addView(tv("🎮  GAMING PROFILE", 15f, green, true))
        c.addView(tv("These controls affect this app only. They do not claim to change the whole phone's CPU/GPU governor.", 12f, muted))
        c.addView(button(if (gamingScreenOn) "SCREEN ON: ENABLED" else "KEEP SCREEN ON", green) {
            gamingScreenOn = !gamingScreenOn
            if (gamingScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            showGaming()
        })
        c.addView(button(if (gamingImmersive) "IMMERSIVE: ENABLED" else "ENABLE IMMERSIVE VIEW", blue) {
            gamingImmersive = !gamingImmersive
            setGamingImmersive(gamingImmersive)
            showGaming()
        })
        c.addView(button("OPEN THIS APP'S BATTERY SETTINGS", orange) { openAppSettings() })
        col.addView(c)

        val info = card()
        listRow(info, "📱", "Device", deviceName())
        listRow(info, "🧠", "RAM", ramSummary())
        listRow(info, "⚙️", "CPU cores", Runtime.getRuntime().availableProcessors().toString())
        listRow(info, "🌡️", "Thermal", thermalSummary())
        col.addView(info)
        setScreen("gaming", scroll)
    }

    private fun showCleaner() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Cleaner", 27f, white, true))
        col.addView(tv("Real cleanup for this app + Android storage controls", 13f, muted))

        val c = card()
        c.addView(tv("🧹  APP CACHE", 16f, green, true))
        c.addView(tv("This app can safely remove its own temporary cache. Android does not let ordinary apps silently clear other apps' private data.", 12f, muted))
        c.addView(tv("Current cache: ${formatBytes(directorySize(cacheDir))}", 14f, white, true))
        c.addView(button("CLEAR SADEE CACHE", green) {
            val before = directorySize(cacheDir)
            clearDirectory(cacheDir)
            statusToast("Cleared ${formatBytes(before)} of SADEE temporary cache")
            showCleaner()
        })
        c.addView(button("OPEN ANDROID APP STORAGE", blue) { openSettings(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS) })
        c.addView(button("OPEN INTERNAL STORAGE", orange) { openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) })
        col.addView(c)

        val info = card()
        listRow(info, "💾", "Internal storage", storageSummary())
        listRow(info, "📦", "SADEE cache", formatBytes(directorySize(cacheDir)))
        listRow(info, "🗑️", "Other app caches", "Managed by Android / user settings")
        col.addView(info)
        setScreen("cleaner", scroll)
    }

    private fun showFreeFire() {
        val (scroll, col) = scrollPage()
        col.addView(tv("Optimize @ Launch Free Fire", 27f, white, true))
        col.addView(tv("Prepare this app, then launch Free Fire automatically", 13f, muted))

        val c = card()
        c.addView(tv("🔥  FREE FIRE LAUNCH", 16f, green, true))
        c.addView(tv("This uses normal Android app-launching APIs. It does not overclock the phone or modify Free Fire files.", 12f, muted))
        c.addView(listRowView("📱", "Device", deviceName()))
        c.addView(listRowView("🧠", "RAM", ramSummary()))
        c.addView(listRowView("🌡️", "Thermal", thermalSummary()))
        c.addView(button("🔥  OPTIMIZE @ LAUNCH FREE FIRE", green) {
            prepareForGaming()
            launchFreeFire()
        })
        col.addView(c)

        val info = card()
        info.addView(tv("SUPPORTED", 11f, muted, true))
        info.addView(tv("Free Fire / Free Fire MAX", 14f, white, true))
        info.addView(tv("If neither app is installed, Android will show a message.", 11f, muted))
        col.addView(info)
        setScreen("freefire", scroll)
    }

    private fun listRowView(icon: String, title: String, value: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(tv(icon, 20f, white, true), LinearLayout.LayoutParams(dp(38), dp(45)))
        val middle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        middle.addView(tv(title, 14f, white, true))
        middle.addView(tv(value, 11f, muted))
        row.addView(middle, LinearLayout.LayoutParams(0, -2, 1f))
        return row
    }

    private fun prepareForGaming() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        gamingScreenOn = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                )
        }
        statusToast("Gaming mode prepared • launching Free Fire")
    }

    private fun launchFreeFire() {
        val packages = listOf("com.dts.freefireth", "com.dts.freefiremax")
        for (packageName in packages) {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                return
            }
        }
        statusToast("Free Fire is not installed")
    }

    private fun showMore() {
        val (scroll, col) = scrollPage()
        col.addView(tv("More", 27f, white, true))
        col.addView(tv("Detailed live device information", 13f, muted))

        val device = card()
        listRow(device, "📱", "Device", deviceName())
        listRow(device, "🏭", "Manufacturer", Build.MANUFACTURER)
        listRow(device, "🤖", "Android", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        listRow(device, "⚙️", "CPU cores", Runtime.getRuntime().availableProcessors().toString())
        listRow(device, "🖥️", "ABI", Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown")
        listRow(device, "📶", "Network", networkSummary())
        listRow(device, "🌡️", "Thermal", thermalSummary())
        col.addView(device)

        val ram = card()
        listRow(ram, "🧠", "RAM", ramSummary())
        listRow(ram, "💾", "Storage", storageSummary())
        listRow(ram, "🔋", "Battery", batterySummary())
        col.addView(ram)

        val license = card()
        license.addView(tv("🔐 LICENSE", 16f, green, true))
        license.addView(tv("Status: ${licenseStatus()}", 13f, white, true))
        license.addView(button("CHANGE / ACTIVATE KEY", blue) { showLicenseGate() })
        col.addView(license)

        val about = card()
        about.addView(tv("SADEE OPTIMIZER 2.0.0", 16f, white, true))
        about.addView(tv("Native Android gaming utility. License-based access.", 12f, muted))
        col.addView(about)
        setScreen("more", scroll)
    }

    private fun listRow(parent: LinearLayout, icon: String, title: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(tv(icon, 20f, white, true), LinearLayout.LayoutParams(dp(38), dp(45)))
        val middle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        middle.addView(tv(title, 14f, white, true))
        middle.addView(tv(value, 11f, muted))
        row.addView(middle, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row)
    }

    private fun button(text: String, color: Int, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(Color.rgb(3, 15, 10))
        background = roundedBackground(color, Color.WHITE, 1, 14f)
        setPadding(dp(10), dp(6), dp(10), dp(6))
        isAllCaps = false
        typeface = Typeface.DEFAULT_BOLD
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, dp(12), 0, 0) }
    }

    private fun deviceName(): String {
        val maker = Build.MANUFACTURER.replaceFirstChar { it.uppercaseChar() }
        val model = Build.MODEL
        return if (model.startsWith(maker, true)) model else "$maker $model"
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "${bytes} B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.getDefault(), "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.getDefault(), "%.1f MB", mb)
        val gb = mb / 1024.0
        if (gb < 1024.0) return String.format(Locale.getDefault(), "%.2f GB", gb)
        val tb = gb / 1024.0
        return String.format(Locale.getDefault(), "%.2f TB", tb)
    }

    private fun ramInfo(): ActivityManager.MemoryInfo {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    private fun ramSummary(): String {
        val info = ramInfo()
        return "${formatBytes(info.availMem)} free / ${formatBytes(info.totalMem)} total"
    }

    private fun storageStat(): StatFs = StatFs(Environment.getDataDirectory().absolutePath)

    private fun storageSummary(): String {
        val stat = storageStat()
        val total = stat.totalBytes
        val free = stat.availableBytes
        return "${formatBytes(total - free)} used / ${formatBytes(total)} total (${formatBytes(free)} free)"
    }

    private fun batterySummary(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = if (Build.VERSION.SDK_INT >= 23) {
            bm.isCharging
        } else false
        return if (level in 0..100) "$level%${if (charging) " • charging" else ""}" else "Unavailable"
    }

    private fun networkSummary(): String {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "Offline"
        val caps = cm.getNetworkCapabilities(network) ?: return "Connected"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }
    }

    private fun thermalSummary(): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Not available on Android < 10"
        val pm = getSystemService(PowerManager::class.java)
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Unknown"
        }
    }

    private fun calculateScore(): Int {
        val ram = ramInfo()
        val ramPct = if (ram.totalMem > 0) (ram.availMem * 100.0 / ram.totalMem).coerceIn(0.0, 100.0) else 0.0
        val stat = storageStat()
        val storagePct = if (stat.totalBytes > 0) (stat.availableBytes * 100.0 / stat.totalBytes).coerceIn(0.0, 100.0) else 0.0
        val battery = (getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
        val thermalBonus = when (thermalSummary()) {
            "Normal" -> 10
            "Light" -> 7
            "Moderate" -> 4
            else -> 0
        }
        return ((ramPct * 0.45) + (storagePct.coerceAtMost(50.0) * 0.30) + (battery * 0.15) + thermalBonus).roundToInt().coerceIn(0, 100)
    }

    private fun refreshMetrics() {
        if (!::ramText.isInitialized) return
        ramText.text = ramSummary().replace(" free / ", "\nfree / ")
        storageText.text = storageSummary().replace(" used / ", "\nused / ").replace(" (", "\n(")
        batteryText.text = batterySummary()
        deviceText.text = deviceName()
        if (::scoreText.isInitialized) scoreText.text = calculateScore().toString()
    }

    private fun directorySize(dir: java.io.File): Long {
        if (!dir.exists()) return 0L
        var total = 0L
        dir.listFiles()?.forEach { file ->
            total += if (file.isDirectory) directorySize(file) else file.length()
        }
        return total
    }

    private fun clearDirectory(dir: java.io.File) {
        dir.listFiles()?.forEach { file ->
            if (file.isDirectory) clearDirectory(file)
            file.delete()
        }
    }

    private fun openSettings(action: String) {
        runCatching { startActivity(Intent(action)) }.onFailure { statusToast("That Android settings page is not available") }
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = android.net.Uri.parse("package:$packageName")
        }
        startActivity(intent)
    }

    private fun setGamingImmersive(enabled: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                if (enabled) {
                    controller.hide(android.view.WindowInsets.Type.systemBars())
                } else {
                    controller.show(android.view.WindowInsets.Type.systemBars())
                }
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enabled) {
                (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
            } else 0
        }
    }

    private fun statusToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onBackPressed() {
        if (gamingImmersive) {
            gamingImmersive = false
            setGamingImmersive(false)
            return
        }
        super.onBackPressed()
    }
}
