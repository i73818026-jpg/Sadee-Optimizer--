# SADEE Optimizer 2.0 Gaming Edition

Native Android utility with a neon gaming-style UI and the supplied SADEE logo.

## Changes
- SADEE logo added to app icon, header and dashboard/gaming hero areas.
- Gaming-focused dark/neon visual design with rounded cards and action buttons.
- Gaming Mode and Free Fire launch flow preserved.
- Real RAM, storage, battery, network and thermal monitoring preserved.
- No root, fake overclocking, or silent clearing of other apps' private data.
- Version bumped to 2.0.0 / versionCode 3.

## Build
The included GitHub Actions workflow builds the debug APK with JDK 17, Gradle 8.9 and Android SDK 35.
